﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba_1
{
    class Airplane
    {
        public string board; // номер брорта
        public int speed; // скорость
        public int altitude; // высота
        public int[] engines = new int[4];

        /*
        public void print()
        {
            Console.WriteLine($"Борт № {board}. Скорость - {speed} км/ч. Высота - {altitude} км.");
        }
        */
        public Airplane(string board, int speed, int altitude) //конструктор
        {
            this.board = board;
            this.speed = speed;
            this.altitude = altitude;

        }

        public int avg()
        {
            return (engines[0] + engines[1] + engines[2] + engines[3]) / 4;
        }


        public override string ToString()
        {
            return $"Борт № {board}." +
                $" Скорость - {speed} км/ч. " +
                $" Высота - {altitude} км." +
                $" Мощность двигателей - {engines[0]}% {engines[1]}% {engines[2]}% {engines[3]}%" +
                $" Средняя мощность двигателей: {avg()} % ";
        }




    }
}
