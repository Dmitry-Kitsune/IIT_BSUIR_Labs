﻿using System;

namespace Laba_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Лабораторная №1");
            Console.WriteLine("Вариант №3");
            Console.WriteLine(" ");

            Airplane plane1 = new Airplane("K90", 800, 9000);
           
            plane1.engines = new int[] { 100, 80, 70, 90 };

            /*Airplane plane1 = new Airplane();
            plane1.board = "K90";
            plane1.speed = 800;
            plane1.altitude = 9000;
            plane1.engines = new int[] { 100, 80, 70, 90 };*/

            Console.WriteLine(plane1);
            //Console.WriteLine($"Средняя мощность двигателей: {plane1.avg()} % ");

            /* Console.WriteLine(
                  $"Борт № { plane1.board}." +
                  $" Скорость - { plane1.speed} " +
                  $"км/ч. Высота - { plane1.altitude} км.");
            */
           
            
            Airplane plane2 = new Airplane("Q13", 920, 10500)
            {
                engines = new int[] { 90, 90, 90, 90 }
            };


            /*  Airplane plane2 = new Airplane()
              {
                  board = "Q13",
                  speed = 920,
                  altitude = 10500,
                  engines = new int [] { 90, 90, 90, 90 }
               };
            */
            //plane2.print();

            Console.WriteLine(plane2);

            Console.ReadLine();
        }
    }
}
